"""Observation-based regression tests. Review expectations before delivery."""

import re

from playwright.sync_api import expect


def test_TC_004(qa_page):
    page, resolve = qa_page
    page.goto(resolve("http://127.0.0.1:8001/inventory"), wait_until="domcontentloaded")
    page.get_by_role("link", name="Moss Journal", exact=True).first.click()
    expect(page).to_have_url(resolve("http://127.0.0.1:8001/supply/moss"))
    expect(page.get_by_role("heading", name="Moss Journal", exact=True).first).to_be_visible()


def test_TC_F_search_found(qa_page):
    page, resolve = qa_page
    page.goto(resolve("http://127.0.0.1:8001/inventory"), wait_until="domcontentloaded")
    page.get_by_role("searchbox", name="Find supplies", exact=True).fill("Moss")
    expect(
        page.get_by_test_id("stock-name"), "search result mismatch: texts EL-1f643c8c0192"
    ).to_have_text(["Moss Journal"])


def test_TC_F_search_empty(qa_page):
    page, resolve = qa_page
    page.goto(resolve("http://127.0.0.1:8001/inventory"), wait_until="domcontentloaded")
    page.get_by_role("searchbox", name="Find supplies", exact=True).fill("unlisted-fixture-904")
    expect(
        page.get_by_test_id("stock-name"), "search result mismatch: count EL-1f643c8c0192"
    ).to_have_count(0)
    expect(
        page.get_by_test_id("stock-empty"), "search result mismatch: visible EL-de2d225cba79"
    ).to_be_visible()
    expect(
        page.get_by_test_id("stock-empty"), "search result mismatch: text EL-de2d225cba79"
    ).to_have_text("No supplies match")


def test_TC_F_filter_writing(qa_page):
    page, resolve = qa_page
    page.goto(resolve("http://127.0.0.1:8001/inventory"), wait_until="domcontentloaded")
    page.get_by_role("combobox", name="Category filter", exact=True).select_option("Writing")
    expect(
        page.get_by_test_id("stock-name"), "filter result mismatch: texts EL-1f643c8c0192"
    ).to_have_text(["Cedar Pencil", "Slate Marker"])


def test_TC_F_sort_low(qa_page):
    page, resolve = qa_page
    page.goto(resolve("http://127.0.0.1:8001/inventory"), wait_until="domcontentloaded")
    page.get_by_role("combobox", name="Sort by price", exact=True).select_option("low")
    expect(
        page.get_by_test_id("stock-price"), "sorting result mismatch: ordered EL-ff12fae654e9"
    ).to_have_count(3)
    values_0 = page.get_by_test_id("stock-price").all_text_contents()
    numbers_0 = [float(re.sub(r"[^0-9.-]", "", value)) for value in values_0]
    assert numbers_0 == sorted(numbers_0, reverse=False), (
        "sorting result mismatch: ordered EL-ff12fae654e9"
    )
    expect(
        page.get_by_test_id("stock-name"), "sorting result mismatch: texts EL-1f643c8c0192"
    ).to_have_text(["Cedar Pencil", "Slate Marker", "Moss Journal"])


def test_TC_F_email_missing(qa_page):
    page, resolve = qa_page
    page.goto(resolve("http://127.0.0.1:8001/request"), wait_until="domcontentloaded")
    page.get_by_role("textbox", name="Work email", exact=True).fill("")
    expect(
        page.get_by_role("textbox", name="Work email", exact=True),
        "form result mismatch: validity EL-63cb0214c759",
    ).to_be_visible()
    assert (
        page.get_by_role("textbox", name="Work email", exact=True).evaluate(
            "(e) => e.validity.valueMissing"
        )
        is True
    ), "form result mismatch: validity EL-63cb0214c759"


def test_TC_F_email_invalid(qa_page):
    page, resolve = qa_page
    page.goto(resolve("http://127.0.0.1:8001/request"), wait_until="domcontentloaded")
    page.get_by_role("textbox", name="Work email", exact=True).fill("not-an-email")
    expect(
        page.get_by_role("textbox", name="Work email", exact=True),
        "form result mismatch: validity EL-63cb0214c759",
    ).to_be_visible()
    assert (
        page.get_by_role("textbox", name="Work email", exact=True).evaluate(
            "(e) => e.validity.typeMismatch"
        )
        is True
    ), "form result mismatch: validity EL-63cb0214c759"


def test_TC_F_quantity_boundary(qa_page):
    page, resolve = qa_page
    page.goto(resolve("http://127.0.0.1:8001/request"), wait_until="domcontentloaded")
    page.get_by_role("spinbutton", name="Sample quantity", exact=True).fill("0")
    expect(
        page.get_by_role("spinbutton", name="Sample quantity", exact=True),
        "form result mismatch: validity EL-5b52af57e8e8",
    ).to_be_visible()
    assert (
        page.get_by_role("spinbutton", name="Sample quantity", exact=True).evaluate(
            "(e) => e.validity.rangeUnderflow"
        )
        is True
    ), "form result mismatch: validity EL-5b52af57e8e8"


def test_TC_F_form_valid(qa_page):
    page, resolve = qa_page
    page.goto(resolve("http://127.0.0.1:8001/request"), wait_until="domcontentloaded")
    page.get_by_role("textbox", name="Contact name", exact=True).fill("Sample QA")
    page.get_by_role("textbox", name="Work email", exact=True).fill("qa@example.test")
    page.get_by_role("spinbutton", name="Sample quantity", exact=True).fill("2")
    page.get_by_role("button", name="Validate sample request", exact=True).click()
    expect(
        page.get_by_test_id("request-status"), "form result mismatch: text EL-ba67547ca632"
    ).to_have_text("Sample request validated")
