"""Observation-based regression tests. Review expectations before delivery."""
from playwright.sync_api import expect


def test_TC_001(qa_page):
    page, resolve = qa_page
    page.goto(resolve('http://127.0.0.1:8000/'), wait_until='domcontentloaded')
    expect(page.get_by_role('heading', name='AutoQA Demo Store', exact=True).first).to_be_visible()

def test_TC_003(qa_page):
    page, resolve = qa_page
    page.goto(resolve('http://127.0.0.1:8000/'), wait_until='domcontentloaded')
    page.get_by_role('link', name='Catalog', exact=True).first.click()
    expect(page).to_have_url(resolve('http://127.0.0.1:8000/products'))
    expect(page.get_by_role('heading', name='Product Catalog', exact=True).first).to_be_visible()

def test_TC_006(qa_page):
    page, resolve = qa_page
    page.goto(resolve('http://127.0.0.1:8000/products'), wait_until='domcontentloaded')
    expect(page.get_by_role('heading', name='Product Catalog', exact=True).first).to_be_visible()

def test_TC_010(qa_page):
    page, resolve = qa_page
    page.goto(resolve('http://127.0.0.1:8000/products'), wait_until='domcontentloaded')
    page.get_by_role('link', name='Atlas Notebook', exact=True).first.click()
    expect(page).to_have_url(resolve('http://127.0.0.1:8000/products/1'))
    expect(page.get_by_role('heading', name='Atlas Notebook', exact=True).first).to_be_visible()

def test_TC_013(qa_page):
    page, resolve = qa_page
    page.goto(resolve('http://127.0.0.1:8000/contact'), wait_until='domcontentloaded')
    expect(page.get_by_role('heading', name='Contact us', exact=True).first).to_be_visible()
